import Amazon from './Analysis/Amazon.png';
import Retouch from './Analysis/Retouch.png';
import Summary from './Analysis/Summary.png';
import Table from './Analysis/Table.png';
import uploadBg from "./logo/dave-upload-bg.png";


export { Amazon, Retouch, Summary, Table, uploadBg };